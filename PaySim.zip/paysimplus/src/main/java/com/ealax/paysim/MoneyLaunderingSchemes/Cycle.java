package com.ealax.paysim.MoneyLaunderingSchemes;

import java.util.ArrayList;
import ec.util.MersenneTwisterFast;

import sim.engine.SimState;
import com.ealax.paysim.actors.Client;
import com.ealax.paysim.actors.MoneyLaunderer;
import com.ealax.paysim.utils.*;
import com.ealax.paysim.PaySim;
import com.ealax.paysim.parameters.Parameters;

public class Cycle extends MLSchemes{

    private int length;//length of the loop
    private ArrayList<Client> loop = new ArrayList<>();
    private ArrayList<Integer> plannedSteps = new ArrayList<>();
    private ArrayList<Double> plannedAmount = new ArrayList<>();




    public Cycle(MoneyLaunderer Orig, SimState state){
        super(Orig, state);
    }

    public void setParameters(){
        PaySim paySim = (PaySim) this.state;
        MersenneTwisterFast random = paySim.random;
        int currentStep = (int) state.schedule.getSteps();

        // set the amount of money that will enter into the loop 
        totalAmount = Orig.getBalance() * this.proportion;


        // set length (is is around 5)
        length = 6 - random.nextInt(3);

        // set clients in the loop
        loop.add(Orig);
        for(int i = 0; i < length - 1; i ++){
            ArrayList<Client> connectedClients = loop.get(i).getConnectedClients();
            Client client = Orig;
            while(!(client instanceof MoneyLaunderer || loop.contains(client))){
                client = connectedClients.get(random.nextInt(connectedClients.size())); 
            }
            loop.add(client);
        }
        loop.add(Orig);

        // set planned steps
        // set the first step
        ArrayList<Integer> candidateSteps = calendarUtils.getCandidateSteps(currentStep, 2);// 2 means the money will sent out the same day or next day
        ArrayList<Integer> optimalSteps = calendarUtils.getOptimalSteps(candidateSteps);
        int firstStep;
        if(random.nextDouble() < 0.9 && optimalSteps.size() > 0){
            firstStep = optimalSteps.get(random.nextInt(optimalSteps.size()));    
        }
        else{
            firstStep = candidateSteps.get(random.nextInt(candidateSteps.size()));
        }
        plannedSteps.add(firstStep);
        // set the left steps
        for(int i = 1; i < length; i++){
            candidateSteps = calendarUtils.getCandidateSteps(plannedSteps.get(i - 1) + 1, 2);
            optimalSteps = calendarUtils.getOptimalSteps(candidateSteps);
            int nextStep;
            if(random.nextDouble() < 0.9 && optimalSteps.size() > 0){
                nextStep = optimalSteps.get(random.nextInt(optimalSteps.size()));    
            }
            else{
                nextStep = candidateSteps.get(random.nextInt(candidateSteps.size()));
            }
            plannedSteps.add(nextStep);
        }

        //set planned amount 
        plannedAmount.add(totalAmount);
        for(int i = 1; i < length; i++){
            double amount = plannedAmount.get(i - 1) * this.ratio;
            plannedAmount.add(amount);
        }

    }

    public void initiate(){
        this.setParameters();
        this.Orig.reserved = this.getTotalAmount();
        this.Orig.MLPlan.add(this);
        ArrayList<Client> loop = this.getLoop();
            for(int i = 1; i < length; i ++){
                Client client = loop.get(i);
                client.MLPlan.add(this);
                client.setSuspicious(true);
            }
    }

    public int getLength(){
        return length;
    }

    public ArrayList<Client> getLoop(){
        return loop;
    }

    public ArrayList<Integer> getPlannedSteps(){
        return plannedSteps;
    }

    public ArrayList<Double> getPlannedAmount(){
        return plannedAmount;
    }

    public double getTotalAmount(){
        return totalAmount;
    }

}
