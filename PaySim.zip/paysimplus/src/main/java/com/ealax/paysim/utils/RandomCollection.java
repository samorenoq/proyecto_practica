package com.ealax.paysim.utils;

import java.util.Collection;
import java.util.NavigableMap;
import java.util.TreeMap;

import ec.util.MersenneTwisterFast;

public class RandomCollection<E> {
    private final NavigableMap<Double, E> map = new TreeMap<>();
    private MersenneTwisterFast random;
    private double total = 0;

    public RandomCollection() {
        this.random = null;
    }

    public RandomCollection(MersenneTwisterFast random) {
        this.random = random;
    }

    public void add(double weight, E result) {
        if (weight > 0) {
            total += weight;
            map.put(total, result);
        }
    }

    public E next() {
        if (this.random == null) {
            throw new NullPointerException("The RNG must be initialized to pick a random element.");
        }
        if (this.map.isEmpty()){
            throw new IllegalStateException("The collection is empty");
        }
        // By the following way, the distribution in the simulation is similar to that in reality, but not identical. (Li)
        double value = random.nextDouble() * total;// nextDouble() returns a random double in the half-open range from [0.0,1.0) (Li)
        return map.higherEntry(value).getValue();// The higherEntry() return a key-value mapping associated with the least key strictly greater than the given key, or null if there is no such key. (Li)
    }

    public Collection<E> getCollection() {
        return map.values();
    }

    public void setRandom(MersenneTwisterFast random) {
        this.random = random;
    }

    public boolean isEmpty() {
        return map.isEmpty();
    }
}