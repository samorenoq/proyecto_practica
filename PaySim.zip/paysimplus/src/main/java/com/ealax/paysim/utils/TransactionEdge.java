package com.ealax.paysim.utils;
import com.ealax.paysim.parameters.Parameters;

import org.jgrapht.*;
import org.jgrapht.graph.*;
import org.jgrapht.nio.Attribute;
import org.jgrapht.nio.DefaultAttribute;
import org.jgrapht.nio.dot.DOTExporter;
//import org.jgrapht.nio.*;
//import org.jgrapht.nio.dot.*;
import org.jgrapht.traverse.*;
import org.jgrapht.util.SupplierUtil;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.*;

public class TransactionEdge extends DefaultEdge {
    private double amount;
    private int date;
    private int day;
    private int time;


    /**
     * Constructs a Transaction edge
     *
     * @param label the label of the new edge.
     * 
     */

    /**
     * Gets the label associated with this edge.
     *
     * @return edge label
     */
    public double getAmount()
    {
        return amount;
    }
    public int getDate()
    {
        return date;
    }
    public int getDay()
    {
        return day;
    }
    public int getTime()
    {
        return time;
    }

    public void setAmount(double amount){
        this.amount = amount;
    }
    public void setDate(int date){
        this.date = date;
    }
    public void setDay(int day){
        this.day = day;
    }
    public void setTime(int time){
        this.time = time;
    }

    @Override
    public String toString()
    {
        return "(" + getSource() + " : " + getTarget() + " : " + amount  + " : " + date  + " : " + day + " : " + time + ")";
    }
}