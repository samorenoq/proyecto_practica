package com.ealax.paysim.utils;
import com.ealax.paysim.parameters.Parameters;

import org.jgrapht.*;
import org.jgrapht.graph.*;
//import org.jgrapht.nio.*;
//import org.jgrapht.nio.dot.*;
import org.jgrapht.traverse.*;
import org.jgrapht.util.SupplierUtil;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.*;


/*
Transaction graph handler will Create a graph then read the parameter file setting the number of clients to add the same number of nodes to the graph
It will then read the Degree.csv file to generate Potential transaction edges between the nodes


In the PaySim.java in the method that performs a transfer instead of picking a random account it will use the Node parameter to pick a connected account
and transfer the money to that account, Since several edges can be between the same nodes some nodes will have a higher probability to recieve a transfer from 
the sender account.

*/
public class TransactionGraphHandler {

    int nbVertices;
    public static void main(String[] args) {

        Parameters.initParameters("PaySim.properties");
        TransactionGraphHandler tg = new TransactionGraphHandler();

        tg.setNbVertices();
        tg.generateVertices();
        tg.generateEdges();

        tg.outputGraph(tg);


        System.out.print("Ran Succesfully");

    }

    //Sets the number of vertices to the number of clients from the properties file
    private void setNbVertices(){
        nbVertices = Parameters.nbClients;
    }

    Supplier<String> vSupplier = new Supplier<String>()
    {
        private int id = 0;

        @Override
        public String get()
        {
            return "v" + id++;
        }
    };


    Graph<String, DefaultEdge> PotentialTransactionGraph =
            new DirectedPseudograph<>(vSupplier, SupplierUtil.createDefaultEdgeSupplier(), false);


    private void generateVertices(){
        for(int i = 0; i < nbVertices; i++){
            PotentialTransactionGraph.addVertex();
        }
    }
    private void generateEdges(){
        PotentialTransactionGraph.addEdge("v1", "v2");
        PotentialTransactionGraph.addEdge("v2", "v3");
        PotentialTransactionGraph.addEdge("v3", "v4");
        PotentialTransactionGraph.addEdge("v5", "v0");
        PotentialTransactionGraph.addEdge("v0", "v5");
        PotentialTransactionGraph.addEdge("v0", "v7");
        }

    private void outputGraph(TransactionGraphHandler tg){

        Iterator<String> iter = new DepthFirstIterator<>(tg.PotentialTransactionGraph);
        while (iter.hasNext()) {
            String vertex = iter.next();
            System.out
                .println(
                    "Vertex " + vertex + " is connected to: "
                        + tg.PotentialTransactionGraph.edgesOf(vertex).toString());
        }
    }

}

