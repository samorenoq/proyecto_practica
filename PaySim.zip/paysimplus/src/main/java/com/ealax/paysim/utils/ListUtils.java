package com.ealax.paysim.utils;

import java.util.ArrayList;
import java.util.Collections;

import ec.util.MersenneTwisterFast;

public class ListUtils {
    
    public static void ListShuffle(ArrayList list, MersenneTwisterFast random){
        for(int i = 0; i < list.size(); i++){
            int size = list.size();
            int j = random.nextInt(size - i) + i;
            Collections.swap(list, i, j);
        }
    }

    public static ArrayList randomSublist(ArrayList list, MersenneTwisterFast random, int num){
        ListShuffle(list, random);
        ArrayList sublist = new ArrayList<>();
        for(int i = 0; i < num; i++){
            Object item = list.get(i);
            sublist.add(item);
        }
        return sublist;
    }



}
