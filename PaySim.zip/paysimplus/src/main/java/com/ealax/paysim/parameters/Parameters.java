package com.ealax.paysim.parameters;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

import com.ealax.paysim.output.Output;

public class Parameters {
    public static String seedString;
    public static int nbClients, nbMerchants, nbBanks, nbFraudsters,nbMoneyLaunderers, nbSteps, initialHour, initialDay, initialDayOfWeek, initialMonth;
    public static double multiplier, fraudProbability, transferLimit;
    public static String aggregatedTransactions, maxOccurrencesPerClient, initialBalancesDistribution,
            overdraftLimits, clientsProfilesFile, transactionsTypes, transactionDegree;
    public static String typologiesFolder, outputPath;
    public static boolean saveToDB;
    public static String dbUrl, dbUser, dbPassword;

    public static StepsProfiles stepsProfiles;
    public static ClientsProfiles clientsProfiles;
    public static DegreeFile degreeFile;

    public static void initParameters(String propertiesFile) {
        loadPropertiesFile(propertiesFile);

        initOthers();
    }

    public static void initParameters(InputStream propertiesInputFile) {
        loadPropertiesFile(propertiesInputFile);

        initOthers();
    }

    private static void initOthers() {
        ActionTypes.loadActionTypes(transactionsTypes);
        BalancesClients.initBalanceClients(initialBalancesDistribution);
        BalancesClients.initOverdraftLimits(overdraftLimits);
        clientsProfiles = new ClientsProfiles(clientsProfilesFile);
        stepsProfiles = new StepsProfiles(aggregatedTransactions, multiplier, nbSteps);
        degreeFile = new DegreeFile(transactionDegree);
        ActionTypes.loadMaxOccurrencesPerClient(maxOccurrencesPerClient);
    }

    private static void loadPropertiesFile(String propertiesFile) {
        try {
            Properties parameters = new Properties();
            parameters.load(new FileInputStream(propertiesFile));

            readProperties(parameters);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void loadPropertiesFile(InputStream propertiesInputFile) {
        try {
            Properties parameters = new Properties();
            parameters.load(propertiesInputFile);

            readProperties(parameters);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void readProperties(Properties parameters) {
        seedString = String.valueOf(parameters.getProperty("seed"));
        nbSteps = Integer.parseInt(parameters.getProperty("nbSteps"));

        initialHour = Integer.parseInt(parameters.getProperty("initialHour"));
        initialDay = Integer.parseInt(parameters.getProperty("initialDay"));
        initialDayOfWeek = Integer.parseInt(parameters.getProperty("initialDayOfWeek"));
        initialMonth = Integer.parseInt(parameters.getProperty("initialMonth"));

        multiplier = Double.parseDouble(parameters.getProperty("multiplier"));

        nbClients = Integer.parseInt(parameters.getProperty("nbClients"));
        nbFraudsters = Integer.parseInt(parameters.getProperty("nbFraudsters"));
        nbMerchants = Integer.parseInt(parameters.getProperty("nbMerchants"));
        nbBanks = Integer.parseInt(parameters.getProperty("nbBanks"));
        nbMoneyLaunderers = Integer.parseInt(parameters.getProperty("nbMoneyLaunderers"));

        fraudProbability = Double.parseDouble(parameters.getProperty("fraudProbability"));
        transferLimit = Double.parseDouble(parameters.getProperty("transferLimit"));

        transactionsTypes = parameters.getProperty("transactionsTypes");
        aggregatedTransactions = parameters.getProperty("aggregatedTransactions");
        maxOccurrencesPerClient = parameters.getProperty("maxOccurrencesPerClient");
        initialBalancesDistribution = parameters.getProperty("initialBalancesDistribution");
        overdraftLimits = parameters.getProperty("overdraftLimits");
        clientsProfilesFile = parameters.getProperty("clientsProfiles");
        transactionDegree = parameters.getProperty("transactionDegree");

        typologiesFolder = parameters.getProperty("typologiesFolder");
        outputPath = parameters.getProperty("outputPath");

        saveToDB = parameters.getProperty("saveToDB").equals("1");
        dbUrl = parameters.getProperty("dbUrl");
        dbUser = parameters.getProperty("dbUser");
        dbPassword = parameters.getProperty("dbPassword");
    }

    public static int getSeed() {
        // /!\ MASON seed is using an int internally
        // https://github.com/eclab/mason/blob/66d38fa58fae3e250b89cf6f31bcfa9d124ffd41/mason/sim/engine/SimState.java#L45
        if (seedString.equals("time")) {
            return (int) (System.currentTimeMillis() % Integer.MAX_VALUE);
        } else {
            return Integer.parseInt(seedString);
        }
    }

    public static String toString(long seed) {
        ArrayList<String> properties = new ArrayList<>();

        properties.add("seed=" + seed);
        properties.add("nbSteps=" + nbSteps);
        properties.add("initialHour=" + initialHour);
        properties.add("initialDate=" + initialDay);
        properties.add("initialDayOfWeek=" + initialDayOfWeek);
        properties.add("initialMonth=" + initialMonth);
        properties.add("multiplier=" + multiplier);
        properties.add("nbFraudsters=" + nbFraudsters);
        properties.add("nbMerchants=" + nbMerchants);
        properties.add("fraudProbability=" + fraudProbability);
        properties.add("transferLimit=" + transferLimit);
        properties.add("transactionsTypes=" + transactionsTypes);
        properties.add("aggregatedTransactions=" + aggregatedTransactions);
        properties.add("clientsProfilesFile=" + clientsProfilesFile);
        properties.add("initialBalancesDistribution=" + initialBalancesDistribution);
        properties.add("maxOccurrencesPerClient=" + maxOccurrencesPerClient);
        properties.add("outputPath=" + outputPath);
        properties.add("saveToDB=" + saveToDB);
        properties.add("dbUrl=" + dbUrl);
        properties.add("dbUser=" + dbUser);
        properties.add("dbPassword=" + dbPassword);
        properties.add("transactionDegree=" + transactionDegree);
        properties.add("nbMoneyLaunderers=" + nbMoneyLaunderers);

        return String.join(Output.EOL_CHAR, properties);
    }
}
