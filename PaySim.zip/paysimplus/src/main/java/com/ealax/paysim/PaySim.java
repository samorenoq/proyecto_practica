package com.ealax.paysim;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.ealax.paysim.actors.Bank;
import com.ealax.paysim.actors.Client;
import com.ealax.paysim.actors.Fraudster;
import com.ealax.paysim.actors.Merchant;
import com.ealax.paysim.actors.MoneyLaunderer;
//import com.ealax.paysim.actors.networkdrugs.NetworkDrug;
import com.ealax.paysim.base.ClientActionProfile;
import com.ealax.paysim.base.StepActionProfile;
import com.ealax.paysim.base.Transaction;
import com.ealax.paysim.output.Output;
import com.ealax.paysim.parameters.ActionTypes;
import com.ealax.paysim.parameters.BalancesClients;
import com.ealax.paysim.parameters.Parameters;

import com.ealax.paysim.utils.PotentialTransactionGraph;
import com.ealax.paysim.utils.TransactionGraph;
import com.ealax.paysim.utils.calendarUtils;

import sim.engine.SimState;

import com.ealax.paysim.parameters.*;

public class PaySim extends SimState {
    public static final double PAYSIM_VERSION = 2.0;
    private static final String[] DEFAULT_ARGS = new String[]{"", "-file", "PaySim.properties", "1"};

    public final String simulationName;
    private int totalTransactionsMade = 0;
    private int stepParticipated = 0;

    private ArrayList<Client> clients = new ArrayList<>();
    private ArrayList<Merchant> merchants = new ArrayList<>();
    private ArrayList<Fraudster> fraudsters = new ArrayList<>();
    private ArrayList<MoneyLaunderer> moneyLaunderers = new ArrayList<>();
    private ArrayList<Bank> banks = new ArrayList<>();
    private int nbMoneyLaunderers = 0;

    private ArrayList<Transaction> transactions = new ArrayList<>();
    private int currentStep;

    private Map<ClientActionProfile, Integer> countProfileAssignment = new HashMap<>();


    //Instansiates a potential transaction graph that reads the number of clients and the degree file to generate vertices and edges
    public PotentialTransactionGraph PTG = new PotentialTransactionGraph();
    public TransactionGraph TG = new TransactionGraph();


    public static void main(String[] args) {
        System.out.println("PAYSIM: Financial Simulator v" + PAYSIM_VERSION);
        if (args.length < 4) {
            args = DEFAULT_ARGS;
        }
        int nbTimesRepeat = Integer.parseInt(args[3]);
        String propertiesFile = "";
        for (int x = 0; x < args.length - 1; x++) {
            if (args[x].equals("-file")) {
                propertiesFile = args[x + 1];
            }
        }
        Parameters.initParameters(propertiesFile);
        for (int i = 0; i < nbTimesRepeat; i++) {
            PaySim p = new PaySim();
            p.runSimulation();
        }
    }

    public PaySim() {
        super(Parameters.getSeed());
        BalancesClients.setRandom(random);
        Parameters.clientsProfiles.setRandom(random);
        PTG.setRandom(random);
        PTG.initiatePTG();

        //initiate the calendarUtils
        int hour = Parameters.initialHour;
        int day = Parameters.initialDay;
        int dayOfWeek = Parameters.initialDayOfWeek;
        int month = Parameters.initialMonth;
        int num = Parameters.nbSteps;
        calendarUtils.initiateCalendar(hour, day, dayOfWeek, month, num);

        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date currentTime = new Date();
        simulationName = "PS_" + dateFormat.format(currentTime) + "_" + seed();

        File simulationFolder = new File(Parameters.outputPath + simulationName);
        simulationFolder.mkdirs();

        System.out.println("simulationFolder:" + simulationFolder.getAbsolutePath());

        Output.initOutputFilenames(simulationName);
        Output.writeParameters(seed());
    }

    public void runSimulation() {
        System.out.println();
        System.out.println("Starting PaySim Running for " + Parameters.nbSteps + " steps.");
        long startTime = System.currentTimeMillis();
        super.start();

        initCounters();
        initActors();

        while ((currentStep = (int) schedule.getSteps()) < Parameters.nbSteps) {
            if (!schedule.step(this))
                break;

            writeOutputStep();
            if (currentStep % 100 == 100 - 1) {
                System.out.println("Step " + currentStep);
            } else {
                System.out.print("*");
            }
        }
        System.out.println();
        System.out.println("Finished running " + currentStep + " steps ");
        finish();

        double total = System.currentTimeMillis() - startTime;
        total = total / 1000 / 60;
        System.out.println("It took: " + total + " minutes to execute the simulation");
        System.out.println("Simulation name: " + simulationName);
        System.out.println();
    }

    private void initCounters() {
        for (String action : ActionTypes.getActions()) {
            for (ClientActionProfile clientActionProfile : Parameters.clientsProfiles.getProfilesFromAction(action)) {
                countProfileAssignment.put(clientActionProfile, 0);
            }
        }
    }

    private void initActors() {
        System.out.println("Init - Seed " + seed());

        //Add the merchants
        System.out.println("NbMerchants: " + (int) (Parameters.nbMerchants * Parameters.multiplier));
        for (int i = 0; i < Parameters.nbMerchants * Parameters.multiplier; i++) {
            Merchant m = new Merchant(generateId());
            merchants.add(m);
        }

        //Add the fraudsters
        System.out.println("NbFraudsters: " + (int) (Parameters.nbFraudsters * Parameters.multiplier));
        for (int i = 0; i < Parameters.nbFraudsters * Parameters.multiplier; i++) {
            Fraudster f = new Fraudster(generateId());
            fraudsters.add(f);
            schedule.scheduleRepeating(f);
        }

        //Add the banks
        System.out.println("NbBanks: " + Parameters.nbBanks);
        for (int i = 0; i < Parameters.nbBanks; i++) {
            Bank b = new Bank(generateId());
            banks.add(b);
        }

        //Add the clients
        //Paysim2 Some of the clients are generated as moneylaunderers
        System.out.println("NbClients: " + (int) (Parameters.nbClients * Parameters.multiplier));
        for (int i = 0; i < Parameters.nbClients * Parameters.multiplier; i++) {
            //Paysim2 client is created with reference to paysim and interator for vertice Id
            int MLChance = random.nextInt(100);
            if(MLChance < 7 && PTG.getDestinations("v" + i).size() > 10){
                MoneyLaunderer c = new MoneyLaunderer(this);
                c.setVertice(i);
                clients.add(c);
                moneyLaunderers.add(c);
                nbMoneyLaunderers++;
            }else{
                Client c = new Client(this);
                c.setVertice(i);
                clients.add(c);
            }
        }

        System.out.println("NbMoneyLaunderers: " + nbMoneyLaunderers);

        /*
        for (int i = 0; i < Parameters.nbMoneyLaunderers * Parameters.multiplier; i++) {
            MoneyLaunderer m = new MoneyLaunderer(this);
            moneyLaunderers.add(m);
            schedule.scheduleRepeating(m);

            m.setVertice(clients.size() + i);
        }
        */

        //Paysim2 removed drug network
        //NetworkDrug.createNetwork(this, Parameters.typologiesFolder + TypologiesFiles.drugNetworkOne);

        // Do not write code under this part otherwise clients will not be used in simulation
        // Schedule clients to act at each step of the simulation
        for (Client c : clients) {
            c.SetConnectedClients(this, c.getVertice());
            schedule.scheduleRepeating(c);
        }
    }

    public Map<String, ClientActionProfile> pickNextClientProfile() {
        Map<String, ClientActionProfile> profile = new HashMap<>();
        for (String action : ActionTypes.getActions()) {
            ClientActionProfile clientActionProfile = Parameters.clientsProfiles.pickNextActionProfile(action);

            profile.put(action, clientActionProfile);

            int count = countProfileAssignment.get(clientActionProfile);
            countProfileAssignment.put(clientActionProfile, count + 1);
        }
        return profile;
    }

    public void finish() {
        Output.writeFraudsters(fraudsters);
        Output.writeClients(clients);
        Output.writeMoneyLaunderers(moneyLaunderers);
        Output.writeClientsProfiles(countProfileAssignment, (int) (Parameters.nbClients * Parameters.multiplier));
        Output.writeSummarySimulation(this);
        Output.writeTransactionGraph(TG);

    }

    private void resetVariables() {
        if (transactions.size() > 0) {
            stepParticipated++;
        }
        transactions = new ArrayList<>();
    }

    private void writeOutputStep() {
        ArrayList<Transaction> transactions = getTransactions();

        totalTransactionsMade += transactions.size();

        Output.incrementalWriteRawLog(currentStep, transactions);
        if (Parameters.saveToDB) {
            Output.writeDatabaseLog(Parameters.dbUrl, Parameters.dbUser, Parameters.dbPassword, transactions, simulationName);
        }

        Output.incrementalWriteStepAggregate(currentStep, transactions);
        resetVariables();
    }

    public String generateId() {
        final String alphabet = "0123456789";
        final int sizeId = 10;
        StringBuilder idBuilder = new StringBuilder(sizeId);

        for (int i = 0; i < sizeId; i++)
            idBuilder.append(alphabet.charAt(random.nextInt(alphabet.length())));
        return idBuilder.toString();
    }

    public Merchant pickRandomMerchant() {
        return merchants.get(random.nextInt(merchants.size()));
    }

    public Bank pickRandomBank() {
        return banks.get(random.nextInt(banks.size()));
    }


    //Paysim2 Picks a random client, not used in paysim2
    public Client pickRandomClient(String nameOrig) {
        Client clientDest = null;

        String nameDest = nameOrig;
        while (nameOrig.equals(nameDest)) {
            clientDest = clients.get(random.nextInt(clients.size()));
            nameDest = clientDest.getName();
        }
        return clientDest;
    }

    //Paysim2 Picks a client from the connected nodes instead of random
    public Client pickConnectedClient(Client orig){
        Client clientDest;
        String vertice = orig.getVertice();
        int destIndex;
        ArrayList<Integer> dest = PTG.getDestinations(vertice);

        if(dest.size() > 0){
            destIndex = dest.get(random.nextInt(dest.size()));
            TG.addEdge(orig.getVertice(), "v"+ destIndex);
        }else{
            System.out.println("Client had no outgoing connections");
            return pickRandomClient(orig.getName());
        }
        clientDest = clients.get(destIndex);
        return clientDest;
    }

    public int getTotalTransactions() {
        return totalTransactionsMade;
    }

    public int getStepParticipated() {
        return stepParticipated;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    public ArrayList<Client> getClients() {
        return clients;
    }

    public ArrayList<MoneyLaunderer> getMoneyLaunderers(){
        return moneyLaunderers;
    }

    public void addClient(Client c) {
        clients.add(c);
    }

    public int getStepTargetCount() {
        return Parameters.stepsProfiles.getTargetCount(currentStep);
    }

    public Map<String, Double> getStepProbabilities() {
        return Parameters.stepsProfiles.getProbabilitiesPerStep(currentStep);
    }

    public StepActionProfile getStepAction(String action) {
        return Parameters.stepsProfiles.getActionForStep(currentStep, action);
    }
}