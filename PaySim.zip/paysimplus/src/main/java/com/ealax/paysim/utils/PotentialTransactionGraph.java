package com.ealax.paysim.utils;
import com.ealax.paysim.parameters.DegreeFile;
import com.ealax.paysim.parameters.Parameters;

import ec.util.MersenneTwisterFast;

import org.jgrapht.*;
import org.jgrapht.graph.*;
import org.jgrapht.nio.*;
import org.jgrapht.nio.dot.*;
import org.jgrapht.traverse.*;
import org.jgrapht.util.SupplierUtil;



import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.*;

/*
The potential transaction graph represent the transactions that could happen. It generates the same amout of vertices as clients by reading the parameter file
Then it generates edges between these vertices by reading the degree file, there can be more potential transactions than actual transaction performed in the simulation

The clients will then be assigned a vertice and check the connected edges when performing a transfer

*/

public class PotentialTransactionGraph {
    
    int nbClientVertices;
    int nbMLVertices;

    MersenneTwisterFast random;

    Supplier<String> vSupplier = new Supplier<String>()
    {
        private int id = 0;

        @Override
        public String get()
        {
            return "v" + id++;
        }
    };

    Graph<String, DefaultEdge> TransactionGraph =
    new DirectedPseudograph<>(vSupplier, SupplierUtil.createDefaultEdgeSupplier(), false);

    public PotentialTransactionGraph(){
        Parameters.initParameters("PaySim.properties");
    }

    //The order is important, money laundering vertices have to be added after the client vertices and edges
    public void initiatePTG(){
        setNbClientVertices();
        generateVertices();
        generateEdges();
        //addMLVertices();
        //generateMLEdges();

    }

    //Sets the nb of vertices to the number of clients + the number of moneylaunderers 
    private void setNbClientVertices(){
        nbClientVertices = Parameters.nbClients;
    }

    private void addMLVertices(){
        nbMLVertices += Parameters.nbMoneyLaunderers;
        for(int i = nbClientVertices; i < nbMLVertices; i++){
            TransactionGraph.addVertex();
        }
    }

    private void generateVertices(){
        for(int i = 0; i < nbClientVertices; i++){
            TransactionGraph.addVertex();
        }
    }

    public void setRandom(MersenneTwisterFast random) {
        this.random = random;
    }

    //Read the degree file generate the edges 
    private void generateEdges(){

        ArrayList<Integer> in_degree = Parameters.degreeFile.getInDegreeList();
        ArrayList<Integer> out_degree = Parameters.degreeFile.getOutDegreeList();

        //Generate list of all sources from out_degree sequence
        ArrayList<Integer> source_list = new ArrayList<>();

        int x = 0;
        for(Integer Value : out_degree ){
            
            for(int j=0; j<Value; j++){

                Integer index_of_vertex = x;
                source_list.add(index_of_vertex);
            }
            x++;
        }

        //Generate list of all destinations from in_degree sequence
        ArrayList<Integer> destination_list = new ArrayList<>();

        int k = 0;
        for(Integer Value : in_degree ){
            for(int j=0; j<Value; j++){

                Integer index_of_vertex = k;
                destination_list.add(index_of_vertex);
            }
            k++;
        }

        // Shuffle the destination list
        for(int m = 0; m < destination_list.size(); m++){
            int dst_size = destination_list.size();
            int n = random.nextInt(dst_size - m) + m;
            Collections.swap(destination_list, m, n);
        }

        // Shuffle the source list
        for(int s = 0; s < source_list.size(); s++){
            int src_size = source_list.size();
            int t = random.nextInt(src_size - s) + s;
            Collections.swap(source_list, s, t);
        }

        //Rearrange the lists to avoid self-loop
        for(int i=0; i < source_list.size(); i++){
            int source = source_list.get(i);
            int destination = destination_list.get(i);
            if(source == destination){
                for(int j = i+1; j < destination_list.size(); j++){
                    if(source != destination_list.get(j) && source != source_list.get(j)){                       
                        Collections.swap(destination_list, i, j);
                        break;
                    }
                }
            }
            int new_destination = destination_list.get(i);
            if(source == new_destination){//If cannot find a suitable dst by searching afterward, then search forward
                for(int j = 0; j < i; j++){
                    if(source != destination_list.get(j) && source != source_list.get(j)){
                        Collections.swap(destination_list, j, i);
                        break;
                    }
                }
            }
            //To check that self-loop is avoidable
            if(source == destination_list.get(i)){
                System.out.println("Warning: There exists self-loop in the potential transactions graph!");
                break;
            }
        }
        
        //Add all edges to the graph
        for(int i = 0; i < source_list.size(); i++){
            TransactionGraph.addEdge("v" + source_list.get(i) , "v" + destination_list.get(i));
        }
    }

    //Generates edges to normal clients
    private void generateMLEdges(){

        int MLvertices = Parameters.nbMoneyLaunderers;

        for(int i = 0; i < MLvertices; i++){
            int min = 5;
            int max = 10;
            int nbMembers;
            nbMembers = random.nextInt(max - min + 1) + min;
            
            for(int j = 0; j < nbMembers; j++){
                int randomClient = random.nextInt(nbClientVertices);
                int randomML = random.nextInt(nbMLVertices);
                
                //Adds an edge from the ML to a random client 
                TransactionGraph.addEdge("v" + (nbClientVertices + i), "v" + randomClient);
                //Adds an outgoing edge from the target client to different ML account
                TransactionGraph.addEdge("v" + randomClient, "v" + randomML);

            }
        }   
    }

    public ArrayList<Integer> getDestinations(String vertex){
        
        Set<DefaultEdge> edges = TransactionGraph.outgoingEdgesOf(vertex);
        Iterator<DefaultEdge> itr = edges.iterator(); 
        ArrayList<String> outgoingEdges = new ArrayList<String>();
        ArrayList<Integer> destinations = new ArrayList<Integer>();

        while(itr.hasNext()){
            outgoingEdges.add(itr.next().toString());
        }

        for(int i = 0; i < outgoingEdges.size(); i++){
            String[] split = outgoingEdges.get(i).split(":");
            String destVertice = split[1];
            destVertice = destVertice.replaceAll("[ )v]", "");
            Integer clientindex = Integer.parseInt(destVertice);
            destinations.add(clientindex);
        }
        return destinations;
    }

    // For test. To Remove when everything is done.
    private void outPutTest(String vertex){
        // Iterator<String> iter = new DepthFirstIterator<>(TransactionGraph);
        // while (iter.hasNext()) {
        //     String vertex = iter.next();

            Set<DefaultEdge> edges = TransactionGraph.edgesOf(vertex);
            Set<DefaultEdge> outEdges = TransactionGraph.outgoingEdgesOf(vertex); 
            ArrayList<Integer> destinations = this.getDestinations(vertex);


            System.out.println(
                "Vertex " + vertex + " is connected to: " + edges);
            System.out.println(
                "The set of out going edges of " + vertex + " are " + outEdges);
                System.out.println(
                "The list of destinations (index) of " + vertex + " are " + destinations);   
        // To export graph as a DOT file.     
        DOTExporter<String, DefaultEdge> exporter = new DOTExporter<>();
        exporter.setVertexAttributeProvider((v) -> {
            Map<String, Attribute> map = new LinkedHashMap<>();
            map.put("label", DefaultAttribute.createAttribute(v));
            return map;
        });
        try{
            Writer writer = new FileWriter("graph.dot");
            exporter.exportGraph(TransactionGraph, writer);
            writer.close();
            //System.out.println(writer.toString());
        }catch(IOException e){
            e.printStackTrace();
        }

    }

}

