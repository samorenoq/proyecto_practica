package com.ealax.paysim.MoneyLaunderingSchemes;

import java.util.ArrayList;
import ec.util.MersenneTwisterFast;

import sim.engine.SimState;
import com.ealax.paysim.actors.Client;
import com.ealax.paysim.actors.MoneyLaunderer;
import com.ealax.paysim.utils.*;
import com.ealax.paysim.PaySim;
import com.ealax.paysim.parameters.Parameters;

public class FanOutFanIn extends MLSchemes{
    
    private final String typology = "FanOutFanIn";
    
    // Attributes for fan out
    private int targetNumber;
    private int duration;
    private ArrayList<Client> targetClients = new ArrayList<>();
    private ArrayList<Integer> plannedSteps = new ArrayList<>();
    private ArrayList<Double> plannedAmount = new ArrayList<>();

    // Attributes for fan in
    private MoneyLaunderer Dest;
    private ArrayList<Integer> plannedStepsFanIn = new ArrayList<>();
    private ArrayList<Double> plannedAmountFanIn = new ArrayList<>();
 


    //create an instance of FanOutFanIn
    public FanOutFanIn(MoneyLaunderer Orig, SimState state){
        super(Orig, state);
    }

    public void setParameters(){
        PaySim paySim = (PaySim) this.state;
        MersenneTwisterFast random = paySim.random;
        
        
        // Determine the target clients
        // Only connected clients are chosen as candidates
        ArrayList<Client> connectedClients = this.Orig.getConnectedClients();

        // Remove money launderers from the candidates
        ArrayList<Client> candidates = new ArrayList<>();
        for(Client client: connectedClients){
            if(!(client instanceof MoneyLaunderer)){
                candidates.add(client);
            }
        }

        // Determine the number of mules that will be used
        targetNumber = Math.min(5 + random.nextInt(6), candidates.size());

        // determine the target clients (mules)
        targetClients = ListUtils.randomSublist(candidates, random, targetNumber);

        // Set timing to perform money laundering
        //Determine the duration
        int currentStep = (int) state.schedule.getSteps();
        int currentDayOfWeek = calendarUtils.getDayOfWeek(currentStep);
            if(currentDayOfWeek == 5 || currentDayOfWeek == 6){
                duration = 7 - currentDayOfWeek + 5;
            }
            else{
                duration = 5 - currentDayOfWeek;
            }

        //get candidate steps
        ArrayList<Integer> candidateSteps = calendarUtils.getCandidateSteps(currentStep, duration);

        //To handle the case that the number of candidate steps is not enough (it normally happens when the scheme is initiated in the evening of friday)
        if(candidateSteps.size() < targetNumber){
            duration = 7 - currentDayOfWeek + 5;
            candidateSteps = calendarUtils.getCandidateSteps(currentStep, duration);
        }

        //To get the optimal candidate steps (steps between 9.00 am - 5.00 pm on weekdays)
        ArrayList<Integer> optimalSteps = calendarUtils.getOptimalSteps(candidateSteps);
        

        //Obtain planned steps for fan out
        for(int i = 0; i < targetNumber; i++){
            double value = random.nextDouble();
            if(value < 0.9 && optimalSteps.size() > 0){
                    int step = optimalSteps.get(random.nextInt(optimalSteps.size()));
                    plannedSteps.add(step);
                    optimalSteps.remove(Integer.valueOf(step));
                }
                else{
                    int step = candidateSteps.get(random.nextInt(candidateSteps.size()));
                    plannedSteps.add(step);
                    candidateSteps.remove(Integer.valueOf(step));
                }
        }

        // Determine the target total amount
        double targetTotalAmount = (Orig.getBalance() - Orig.reserved) * proportion;

        // Determine the list of planned amounts 
        // TODO: to check that the following codes work as expected
        double average = targetTotalAmount / targetNumber;
        double std = average * 0.3 / 4;
        for(int i = 0; i < targetNumber; i++){
            double amount = -1;
            while (amount <= 0) {
                amount = random.nextGaussian() * std + average;
            }
            plannedAmount.add(amount);
        }

        // To ensure that the total amount is near to the target amount
        totalAmount = 0;
        for(double amount : plannedAmount){
            totalAmount += amount;
        }
        while(totalAmount > targetTotalAmount){
            totalAmount = 0;
            for(int i = 0; i < plannedAmount.size(); i++){
                double amount = plannedAmount.get(i) * 0.95;
                plannedAmount.set(i, amount);
                totalAmount += amount;
            }
        }
        while(totalAmount < targetTotalAmount){
            totalAmount = 0;
            for(int i = 0; i < plannedAmount.size(); i++){
                double amount = plannedAmount.get(i) * 1.05;
                plannedAmount.set(i, amount);
                totalAmount += amount;
            }
        }

        //Part II: Fan in

        // Determine the destination
        String nameDest = Orig.getName();
        ArrayList<MoneyLaunderer> moneyLaunderers = paySim.getMoneyLaunderers();
            while (Orig.getName().equals(nameDest)) {
                Dest = moneyLaunderers.get(random.nextInt(moneyLaunderers.size()));
                nameDest = Dest.getName();
            }

        // Determine the fan in steps (mule clients will transfer money out no later than 5 days from they receive the money)

        for(int step: plannedSteps){
            ArrayList<Integer> candidateStepsFanIn = calendarUtils.getCandidateSteps(step + 1, 5);
            int stepFanIn = candidateStepsFanIn.get(random.nextInt(candidateStepsFanIn.size()));
            plannedStepsFanIn.add(stepFanIn);
        }

        // Determine the amount for fan in
        for(double amount: plannedAmount){
            double amountFanIn = amount * ratio;// TODO: the propotion would be read from parameter files 
            plannedAmountFanIn.add(amountFanIn);
        }
    }

    public void initiate(){
        this.setParameters();
        this.Orig.reserved += this.getTotalAmount();
        this.Orig.MLPlan.add(this);
        ArrayList<Client> targetClients = this.getTargeClients();
            for(Client client: targetClients){
                client.MLPlan.add(this);
                client.setSuspicious(true);
            }
    }

    public String getType(){
        return typology;
    }

    public double getTotalAmount(){
        return totalAmount;
    }

    public double getTargetNumber(){
        return targetNumber;
    }

    public int getDuration(){
        return duration;
    }

    public ArrayList<Client> getTargeClients(){
        return targetClients;
    }


    public ArrayList<Integer> getPlannedSteps(){
        return plannedSteps;
    }

    public ArrayList<Double> getPlannedAmount(){
        return plannedAmount;
    }

    public MoneyLaunderer getDest(){
        return Dest;
    }

    public ArrayList<Integer> getPlannedStepsFanIn(){
        return plannedStepsFanIn;
    }

    public ArrayList<Double> getPlannedAmountFanIn(){
        return plannedAmountFanIn;
    }

    public boolean isOnGoing(int step){
        if(step <= plannedSteps.get(plannedSteps.size() - 1)){
            return true;
        }
        else{
            return false;
        }
    }

}
