package com.ealax.paysim.utils;
import java.util.ArrayList;

public class calendarUtils {
    public static final int Mon = 0;
    public static final int Tue = 1;
    public static final int Wed = 2;
    public static final int Thu = 3;
    public static final int Fri = 4;
    public static final int Sat = 5;
    public static final int Sun = 6;

    // Assume each month has 30 days
    // hour, date, day of the week

    private static int initialHour;
    private static int initialDay;
    private static int initialDayOfWeek;
    private static int initialMonth;
    private static int nbSteps;

    public static void initiateCalendar(int hour, int day, int dayOfWeek, int month, int num){
        // TODO: To check that 0<=hour<=23, 0<=day<=29, 0<=dayOfWeek<=6, 0<=month<=11      
        initialHour = hour;
        initialDay = day;
        initialDayOfWeek = dayOfWeek;
        initialMonth = month;
        nbSteps = num;
    }

    public static int getHour(int step){
        return (step + initialHour) % 24;
    }

    public static int getDay(int step){
        return ((step + initialHour) / 24 + initialDay) % 30;
    }

    public static int getDayOfWeek(int step){
        return ((step + initialHour) / 24 + initialDayOfWeek) % 7;
    } 

    public static int getMonth(int step){
        return ((step + initialHour) / 24 + initialDay) / 30 + initialMonth;
    }

    public static ArrayList<Integer> getDate(int step){
        int day = getDay(step);
        int month = getMonth(step);
        ArrayList<Integer> date = new ArrayList<>();
        date.add(month);
        date.add(day);
        return date;
    }

    public static ArrayList<Integer> getTime(int step){
        int hour = getHour(step);
        ArrayList<Integer> date = getDate(step);
        date.add(hour);
        return date;
    }


    public static int getStep(ArrayList<Integer> time){
        int initialValue = ((initialMonth) * 30 + initialDay) * 24 + initialHour;
        int month = time.get(0);
        int day = time.get(1);
        int hour = time.get(2);
        int value = ((month) * 30 + day) * 24 + hour;
        return value - initialValue;
    }

    public static boolean isEarlier(ArrayList<Integer> time_1, ArrayList<Integer> time_2){
        int value_1 = (time_1.get(0) * 30 + time_1.get(1)) * 24 + time_1.get(2);
        int value_2 = (time_2.get(0) * 30 + time_2.get(1)) * 24 + time_2.get(2);
        if(value_1 < value_2){
            return true;
        }
        else{
            return false;
        }
    } 

    public static ArrayList<ArrayList<Integer>> getCalendar(){
        ArrayList<ArrayList<Integer>> calendar = new ArrayList<>();
        ArrayList<Integer> date = getDate(0);
        calendar.add(date); 
        for(int i = 1; i < nbSteps; i++){
            ArrayList<Integer> previousDate = calendar.get(i - 1);
            ArrayList<Integer> currentDate = getDate(i);
            if(currentDate != previousDate){
                calendar.add(currentDate);
            }
        }    
        return calendar;
    }

    // Use to calculate the date several days later
    public static ArrayList<Integer> calcDate(ArrayList<Integer> date, int num){
        int month = date.get(0) + (date.get(1) + num ) / 30;
        int day = (date.get(1) + num ) % 30;
        ArrayList<Integer> result = new ArrayList<>();
        result.add(month);
        result.add(day);
        return result;
    }


    // Use to get candidate steps of a scheme from two inputs: current step, duration (number of days)
    public static ArrayList<Integer> getCandidateSteps(int currentStep, int duration){
        ArrayList<Integer> today = calendarUtils.getDate(currentStep); 
        ArrayList<Integer> latestDate = calendarUtils.calcDate(today, duration - 1);
        ArrayList<Integer> candidateSteps = new ArrayList<>();
        int earliestStep = currentStep;
        latestDate.add(23);
        int latestStep = calendarUtils.getStep(latestDate);
        int value = earliestStep;
        while(value <= latestStep){
            candidateSteps.add(value);
            value++;
        }
        return candidateSteps;
    } 

    // Use to get the optimal candidate steps (steps between 9.00 am - 5.00 pm on weekdays)
    public static ArrayList<Integer> getOptimalSteps(ArrayList<Integer> candidateSteps){
        ArrayList<Integer> optimalSteps = new ArrayList<>();
        for(int step: candidateSteps){
            int dayOfWeek = calendarUtils.getDayOfWeek(step);
            int hour = calendarUtils.getHour(step);
            if(dayOfWeek <= 4 && 9 <= hour && hour <= 17){
                optimalSteps.add(step);
            }
        }
        return optimalSteps;
    }






}
