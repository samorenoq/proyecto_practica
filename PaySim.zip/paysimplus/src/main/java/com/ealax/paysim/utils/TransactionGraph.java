package com.ealax.paysim.utils;
import com.ealax.paysim.parameters.Parameters;
import com.ealax.paysim.utils.TransactionEdge;

import org.jgrapht.*;
import org.jgrapht.graph.*;
import org.jgrapht.nio.Attribute;
import org.jgrapht.nio.DefaultAttribute;
import org.jgrapht.nio.dot.DOTExporter;
//import org.jgrapht.nio.*;
//import org.jgrapht.nio.dot.*;
import org.jgrapht.traverse.*;
import org.jgrapht.util.SupplierUtil;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.*;


//Paysim2 Graph of the actual transactions that took place
public class TransactionGraph {

    public int nbVertices;

    Supplier<String> vSupplier = new Supplier<String>()
    {
        private int id = 0;

        @Override
        public String get()
        {
            return "v" + id++;
        }
    };

    Graph<String, TransactionEdge> TransactionGraph =
    new DirectedPseudograph<>(vSupplier, TRANSACTION_EDGE_SUPPLIER, false);

    public TransactionGraph(){
        Parameters.initParameters("PaySim.properties");

        setNbVertices();
        generateVertices();
    }

    private void setNbVertices(){
        nbVertices = Parameters.nbClients;
    }

    private void generateVertices(){
        for(int i = 0; i < nbVertices; i++){
            TransactionGraph.addVertex();
        }
    }

    public void addEdge(String out, String in){
        TransactionGraph.addEdge(out, in);
    }

    public ArrayList<Integer> getDestinations(String vertex){
        
        Set<TransactionEdge> edges = TransactionGraph.outgoingEdgesOf(vertex);
        Iterator<TransactionEdge> itr = edges.iterator(); 
        ArrayList<String> outgoingEdges = new ArrayList<String>();
        ArrayList<Integer> destinations = new ArrayList<Integer>();

        while(itr.hasNext()){
            outgoingEdges.add(itr.next().toString());
        }

        for(int i = 0; i < outgoingEdges.size(); i++){
            String[] split = outgoingEdges.get(i).split(":");
            String destVertice = split[1];
            destVertice = destVertice.replaceAll("[ )v]", "");
            Integer clientindex = Integer.parseInt(destVertice);
            destinations.add(clientindex);
        }
        return destinations;
    }

    public void generateDotFile(){
        
        DOTExporter<String, TransactionEdge> exporter = new DOTExporter<>();
        exporter.setVertexAttributeProvider((v) -> {
            Map<String, Attribute> map = new LinkedHashMap<>();
            map.put("label", DefaultAttribute.createAttribute(v));
            return map;
        });
        try{
            Writer writer = new FileWriter("graph.dot");
            exporter.exportGraph(TransactionGraph, writer);
            writer.close();
            //System.out.println(writer.toString());
        }catch(IOException e){
            e.printStackTrace();
        }

        
    }

    public static final Supplier<TransactionEdge> TRANSACTION_EDGE_SUPPLIER =
    (Supplier<TransactionEdge> & Serializable) TransactionEdge::new;
    
}
