package com.ealax.paysim.actors;

class SuperActor {
    private final String name;
    private boolean isFraud = false;
    private boolean isSuspicious = false;
    double balance = 0;
    public double reserved = 0;
    double overdraftLimit;


    private String vertice;

    SuperActor(String name) {
        this.name = name;
    }

    void deposit(double amount) {
        balance += amount;
    }

    boolean withdraw(double amount) {
        boolean unauthorizedOverdraft = false;

        if (balance - amount - reserved < overdraftLimit) {
            unauthorizedOverdraft = true;
        } else {
            balance -= amount;
        }

        return unauthorizedOverdraft;
    }

    boolean isFraud() {
        return isFraud;
    }
    boolean isSuspicious(){
        return isSuspicious;
    }

    void setFraud(boolean isFraud) {
        this.isFraud = isFraud;
    }

    //Suspicious means that it is likely moneylaundering
    void setSuspicious(boolean isSuspicious){
        this.isSuspicious = isSuspicious;
    }

    public double getBalance() {
        return balance;
    }

    public String getName() {
        return name;
    }

    public void setVertice(int verticeId){
        vertice = "v" + verticeId;
    }
    
    public String getVertice(){
        return vertice;
    }

    @Override
    public String toString() {
        return name;
    }
}
