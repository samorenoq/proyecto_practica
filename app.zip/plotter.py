#!/usr/bin/env python3

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd

class Plotter:
    def __init__(self, data, color_map='plasma', usetex=True, folder_save=""):
        self.color_map = color_map
        self.folder_save = folder_save
        self.data = pd.read_csv(data)
        self.data_tt = self.data.groupby('action')
        self.__set_matplotlib_configs__(usetex)

    def __set_matplotlib_configs__(self, usetex):
        """Setting up all the matplotlib configurations."""

        if usetex:
            matplotlib.rc('text', usetex=True)
            plt.rcParams.update({'font.size': 14})

    def create_plot_axis(self, number_of_rows, number_of_columns):
        """Get the axis and the figure for a given layout."""
        size = (7.5 * number_of_columns, 6 * number_of_rows)
        fig, axs = plt.subplots(number_of_rows, number_of_columns, figsize=size)
        return fig, axs

    def get_colors(self, number_of_colors):
        """List of colors for the selected color map."""
        color1 = plt.get_cmap(self.color_map)

        partition = [0.5]
        if number_of_colors > 1:
            num = number_of_colors - 1
            partition = np.arange(number_of_colors) / num

        colors_list = color1(partition)

        return colors_list

    def savefig(self, fig, name):
        """Saves a figure in a file."""
        if self.folder_save != '' and not os.path.isdir(self.folder_save):
            os.mkdir(self.folder_save)

        path_fig = os.path.join(self.folder_save, name)
        fig.savefig(path_fig, bbox_inches='tight')

    def plot_actions(self):
        """Plots all transactions with fraud included"""
        title = lambda act: f'{act} for all transactions'
        self.plot_all_series(self.data_tt, title)

    def plot_fraud(self):
        """Plots the series for the fraudulent transactions."""

        # Flag fraud
        data_tt = self.data[self.data['isFraud'] == 1].groupby('action')
        title = lambda act: f'{act} for fraud transactions'
        self.plot_all_series(data_tt, title, string='fraud')

        # Money laundering
        data_tt = self.data[self.data['isMoneyLaundering'] == 1].groupby('action')
        title = lambda act: f'{act} for money laundering'
        self.plot_all_series(data_tt, title, string='ml')

    def plot_all_series(self, data_tt, get_title, string='time-series'):
        """This method plots all transaction type series for a data frame."""
        for action, data in data_tt:
            data_step = data.groupby('step')
            low = data_step['amount'].min()
            med = data_step['amount'].mean()
            high = data_step['amount'].max()

            # Plot each one
            fig, ax = self.create_plot_axis(1, 1)
            colors = self.get_colors(3)

            ax.plot(low.index, low, color=colors[0], label='Minimum')
            ax.plot(med.index, med, color=colors[1], label='Mean')
            ax.plot(high.index, high, color=colors[2], label='Maximum')
            ax.legend()
            ax.set_title(get_title(action.replace('_', '\\_')))
            self.savefig(fig, f'{string}-{action}.png')

    def plot_distributions(self):
        """Plot all histogram for distributions."""
        for action, data_tt in self.data_tt:
            amount = data_tt['amount']
            fig, ax = self.create_plot_axis(1, 1)

            _, _, patches = ax.hist(amount, ec='white', density=True)

            # Colors
            colors = self.get_colors(len(patches))
            for c, p in zip(colors, patches):
                plt.setp(p, 'facecolor', c)

            ax.set_title(action.replace('_', '\\_') + ' distribution')
            self.savefig(fig, f'dist-{action}.png')

    def plot_neighbors(self):
        """Plot all histogram for distributions."""

        data_ents = self.data.groupby('nameOrig')
        neighbors = data_ents['nameDest'].value_counts()

        fig, ax = self.create_plot_axis(1, 1)
        colors = self.get_colors(neighbors.size)
        ax.scatter(range(neighbors.size), neighbors, c=colors)
        ax.set_title('Number of Neighbors')
        self.savefig(fig, f'dist-neighbors.png')

        fig, ax = self.create_plot_axis(1, 1)
        quantiles = neighbors.quantile([0.05, 0.95])
        neighbors = neighbors[neighbors.between(*quantiles)]
        _, _, patches = ax.hist(neighbors, ec='white')

        # Colors
        colors = self.get_colors(len(patches))
        for c, p in zip(colors, patches):
            plt.setp(p, 'facecolor', c)

        ax.set_title('Distribution of neighbors (0.05, 0.95)')
        self.savefig(fig, f'dist-percentiles.png')

    def plot_all(self):
        """Plots all posible methods."""
        self.plot_actions()
        self.plot_fraud()
        self.plot_distributions()
        self.plot_neighbors()

if __name__ == '__main__':
    data = '../../../resources/data/paysim/project/rawLog.csv'
    plotter = Plotter(data, folder_save='plots')
    plotter.plot_all()
