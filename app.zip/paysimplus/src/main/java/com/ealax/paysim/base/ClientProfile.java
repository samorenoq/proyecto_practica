package com.ealax.paysim.base;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.ealax.paysim.parameters.ActionTypes;
import ec.util.MersenneTwisterFast;

public class ClientProfile {
    private Map<String, ClientActionProfile> profile;
    private Map<String, Double> actionProbability = new HashMap<>();
    private final Map<String, Integer> targetCount = new HashMap<>();
    private int clientTargetCount;

    public ClientProfile(Map<String, ClientActionProfile> profile, MersenneTwisterFast random) {
        this.profile = profile;
        this.clientTargetCount = 0;
        for (String action : ActionTypes.getActions()) {
            int targetCountAction = pickTargetCount(action, random);
            targetCount.put(action, targetCountAction);
            clientTargetCount += targetCountAction;
        }
        computeActionProbability();
    }

    // Randomly choose a number between MinCount and MaxCount as the target count of a specific action
    // that some agent should perform (Li)
    // clinetTargetCount = sum_{action \in actionTypes}targetCountAction (Li)
    private int pickTargetCount(String action, MersenneTwisterFast random) {
        ClientActionProfile actionProfile = profile.get(action);
        int targetCountAction;

        int rangeSize = actionProfile.getMaxCount() - actionProfile.getMinCount();

        if (rangeSize == 0) {
            targetCountAction = actionProfile.getMinCount();
        } else {
            targetCountAction = actionProfile.getMinCount() + random.nextInt(rangeSize);
        }

        //TODO: check if this is really mandatory
        // It depends on how we determined the values in /paramFiles/maxOccurencesPerClient.csv (Li)
        int maxCountAction = ActionTypes.getMaxOccurrenceGivenAction(actionProfile.getAction());
        if (targetCountAction > maxCountAction) {
            targetCountAction = maxCountAction;
        }

        return targetCountAction;
    }


    // actionProbability = {action \in ActionTypes| (action, targetCountAction / clientTargetCount)} (Li)
    private void computeActionProbability() {
        actionProbability = targetCount.entrySet()
                .stream().collect(Collectors.toMap(
                        Map.Entry::getKey,
                        c -> ((double) c.getValue()) / clientTargetCount)
                );
    }

    public Map<String, Double> getActionProbability() {
        return actionProbability;
    }

    public int getClientTargetCount() {
        return clientTargetCount;
    }

    public ClientActionProfile getProfilePerAction(String action) {
        return profile.get(action);
    }
}
