package com.ealax.paysim.utils;

import java.io.*;
import java.util.ArrayList;

public class CSVReader {
    private static final String CSV_SEPARATOR = ",";

    public static ArrayList<String[]> read(String csvFile) {
        try {
            return CSVReader.readCSVFile(csvFile);
        } catch (RuntimeException e) {
            return CSVReader.readCSVInputStreamFile(csvFile);
        }

    }

    public static ArrayList<String[]> readCSVFile(String csvFile) {
        ArrayList<String[]> csvContent = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Skip header
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                csvContent.add(line.split(CSV_SEPARATOR));
            }
        } catch (FileNotFoundException e) {
            System.out.println("File '"+ csvFile +"' does not exists, trying to read it as inputstream");
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return csvContent;
    }

    public static ArrayList<String[]> readCSVInputStreamFile(String csvFile) {
        ArrayList<String[]> csvContent = new ArrayList<>();
        InputStream is = CSVReader.class.getClassLoader().getResourceAsStream(csvFile);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            // Skip header
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                csvContent.add(line.split(CSV_SEPARATOR));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return csvContent;
    }
}
