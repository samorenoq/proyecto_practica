package com.ealax.paysim.MoneyLaunderingSchemes;

import java.util.ArrayList;
import ec.util.MersenneTwisterFast;

import sim.engine.SimState;
import com.ealax.paysim.actors.Client;
import com.ealax.paysim.actors.MoneyLaunderer;
import com.ealax.paysim.utils.*;
import com.ealax.paysim.PaySim;
import com.ealax.paysim.parameters.Parameters;

public class Cycle extends MLSchemes{

    private int num;//number of suspicious clients in the loop
    private double totalAmount;
    private ArrayList<Client> loop = new ArrayList<>();
    private ArrayList<Integer> plannedSteps = new ArrayList<>();
    private ArrayList<Double> plannedAmount = new ArrayList<>();


    public Cycle(MoneyLaunderer Orig, SimState state){
        super(Orig, state);
    }

    public void setParameters(){
        PaySim paySim = (PaySim) this.state;
        MersenneTwisterFast random = paySim.random;
        int currentStep = (int) state.schedule.getSteps();

        // set num (is is around 4)
        num = 5 - random.nextInt(3);

        // set clients in the loop
        loop.add(Orig);

        ArrayList<Client> candidates = new ArrayList<>();

        if(Orig.getMoneyMules().isEmpty()){
            ArrayList<Client> connectedClients = Orig.getConnectedClients();
            for(Client client: connectedClients){
                if(!(client instanceof MoneyLaunderer)){
                    candidates.add(client);
                }
            }
            int limit = candidates.size();
            int expectedNb = Parameters.MoneyLaundererThreshold;
            candidates = ListUtils.randomSublist(candidates, random, Math.min(expectedNb, limit));
            Orig.setMoneyMules(candidates);
        }
        else{
            candidates = this.Orig.getMoneyMules();
        }

        loop.add(candidates.get(random.nextInt(candidates.size())));

        for(int i = 1; i < num; i ++){
            ArrayList<Client> connectedClients = loop.get(i).getConnectedClients();
            Client client = Orig;

            if(connectedClients.isEmpty() || loop.containsAll(connectedClients)){
                while(client instanceof MoneyLaunderer){
                    client = paySim.pickRandomClient(loop.get(i).getName());
                }            
            } 
            else{
                while(client instanceof MoneyLaunderer || loop.contains(client)){
                    client = connectedClients.get(random.nextInt(connectedClients.size())); 
                }
            }
            loop.add(client);
        }

        // set planned steps
        // set the first step
        ArrayList<Integer> candidateSteps = calendarUtils.getCandidateSteps(currentStep, 2);// 2 means the money will sent out the same day or next day
        ArrayList<Integer> optimalSteps = calendarUtils.getOptimalSteps(candidateSteps);
        int firstStep;
        if(random.nextDouble() < 0.9 && optimalSteps.size() > 0){
            firstStep = optimalSteps.get(random.nextInt(optimalSteps.size()));    
        }
        else{
            firstStep = candidateSteps.get(random.nextInt(candidateSteps.size()));
        }
        plannedSteps.add(firstStep);
        // set the left steps
        for(int i = 1; i < num + 1; i++){
            candidateSteps = calendarUtils.getCandidateSteps(plannedSteps.get(i - 1) + 1, 2);
            optimalSteps = calendarUtils.getOptimalSteps(candidateSteps);
            int nextStep;
            if(random.nextDouble() < 0.9 && optimalSteps.size() > 0){
                nextStep = optimalSteps.get(random.nextInt(optimalSteps.size()));    
            }
            else{
                nextStep = candidateSteps.get(random.nextInt(candidateSteps.size()));
                while(optimalSteps.contains(nextStep)){
                    nextStep = candidateSteps.get(random.nextInt(candidateSteps.size()));
                }
            }
            plannedSteps.add(nextStep);
        }

        // Determine total amount
        double availableAmount = (this.Orig.getBalance() - this.Orig.reserved) * proportion;
        double targetTotalAmount = Math.min(availableAmount, Parameters.CycleCap);
        double std = targetTotalAmount * 0.6 / 4;
        totalAmount = 0;
        while (totalAmount <= 0 || totalAmount > targetTotalAmount) {
            totalAmount = random.nextGaussian() * std + targetTotalAmount;
        }

        // while(totalAmount > targetTotalAmount){
        //     totalAmount = totalAmount * 0.95;
        // }


        //set planned amount 
        plannedAmount.add(totalAmount);
        for(int i = 1; i < num + 1; i++){
            double amount = plannedAmount.get(i - 1) * ratio;
            plannedAmount.add(amount);
        }

    }

    public void initiate(){
        this.setParameters();
        this.Orig.reserved += this.totalAmount;
        this.Orig.MLPlan.add(this);
        ArrayList<Client> loop = this.getLoop();
            for(int i = 1; i < num + 1 ; i ++){
                Client client = loop.get(i);
                client.MLPlan.add(this);
            }
    }

    public int getNum(){
        return num;
    }

    public ArrayList<Client> getLoop(){
        return loop;
    }

    public ArrayList<Integer> getPlannedSteps(){
        return plannedSteps;
    }

    public ArrayList<Double> getPlannedAmount(){
        return plannedAmount;
    }

}
