package com.ealax.paysim.actors;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import static java.lang.Math.max;

import java.util.ArrayList;

import com.ealax.paysim.output.Output;
import com.ealax.paysim.parameters.ActionTypes;
import com.ealax.paysim.parameters.BalancesClients;
import com.ealax.paysim.parameters.Parameters;
import ec.util.MersenneTwisterFast;
import sim.engine.SimState;
import sim.engine.Steppable;
import sim.util.distribution.Binomial;

import com.ealax.paysim.PaySim;

import com.ealax.paysim.base.ClientActionProfile;
import com.ealax.paysim.base.ClientProfile;
import com.ealax.paysim.base.StepActionProfile;
import com.ealax.paysim.base.Transaction;
import com.ealax.paysim.utils.PotentialTransactionGraph;
import com.ealax.paysim.utils.RandomCollection;
import com.ealax.paysim.MoneyLaunderingSchemes.*;

public class Client extends SuperActor implements Steppable {
    private static final String CLIENT_IDENTIFIER = "C";
    private static final int MIN_NB_TRANSFER_FOR_FRAUD = 3;
    private static final String CASH_IN = "CASH_IN", CASH_OUT = "CASH_OUT", DEBIT = "DEBIT",
            PAYMENT = "PAYMENT", TRANSFER = "TRANSFER", DEPOSIT = "DEPOSIT";
    protected Bank bank;//Client has an account in some bank
    private ClientProfile clientProfile; //from base/ directory
    protected double clientWeight; //
    private double balanceMax = 0; //
    private int countTransferTransactions = 0; //
    private double expectedAvgTransaction = 0; //
    protected double initialBalance; // 
    protected double launderedMoney = 0;
    protected int totalTransactions = 0;
    protected int totalTransfers = 0;
    protected int totalMLTransfers = 0;
    protected int nbCycle = 0;
    protected int nbFanOutFanIn = 0;

    //A list of schemes, in which the client/money launder is involved
    public ArrayList<MLSchemes> MLPlan= new ArrayList<>();

    //Paysim2 A string representing the vertice to be assigned
    //public String vertice = "";
    //A list of the connected clients
    protected ArrayList<Client> connectedClients = new ArrayList<Client>();

    protected boolean isSuspicious = false;
    protected boolean isMoneyLaunderer = false;

    //whether the client (money launderer) is performing suspicious activity
    protected boolean isLaunderingMoney = false;

    Client(String name, Bank bank) {// Name + bank is enough for creating a client
        super(CLIENT_IDENTIFIER + name);
        this.bank = bank;
    }

    public Client(PaySim paySim) {// Use PaySim to generate a client
        super(CLIENT_IDENTIFIER + paySim.generateId());
        this.bank = paySim.pickRandomBank();
        this.clientProfile = new ClientProfile(paySim.pickNextClientProfile(), paySim.random);
        this.clientWeight = ((double) clientProfile.getClientTargetCount()) /  Parameters.stepsProfiles.getTotalTargetCount();
        this.initialBalance = BalancesClients.pickNextBalance(paySim.random);
        this.balance = initialBalance;
        this.overdraftLimit = pickOverdraftLimit(paySim.random);

        if(this instanceof MoneyLaunderer){
            isMoneyLaunderer = true;
        }
    }

    @Override
    public void step(SimState state) {
        PaySim paySim = (PaySim) state;
        int stepTargetCount = paySim.getStepTargetCount();
        int currentStep = (int) state.schedule.getSteps();

        this.isLaunderingMoney = true;

        //Perform suspicious actions
        for(MLSchemes scheme: this.MLPlan){
            if(scheme instanceof FanOutFanIn){
                FanOutFanIn scheme_fan = (FanOutFanIn) scheme;
                if(scheme_fan.getPlannedStepsFanIn().contains(currentStep)){
                    int index = scheme_fan.getTargeClients().indexOf(this);
                    if(scheme_fan.getPlannedStepsFanIn().get(index) == currentStep){
                        double amount = scheme_fan.getPlannedAmountFanIn().get(index);
                        Client clientTo = scheme_fan.getDest();
                        handleTransfer(paySim, currentStep, amount, clientTo);
                        launderedMoney += amount;
                        totalTransactions += 1;
                        // System.out.println("ORDINARY CLIENT performed fan out fan in with:" + amount + "from" + this.getName() + "to" + clientTo.getName());
                    }   
                }
            }

            if(scheme instanceof Cycle){
                Cycle scheme_cycle = (Cycle) scheme;
                ArrayList<Client> loop = scheme_cycle.getLoop();
                if(scheme_cycle.getPlannedSteps().contains(currentStep)){
                    int index = scheme_cycle.getPlannedSteps().indexOf(currentStep);
                    if(loop.get(index) == this){
                        if(index == loop.size() - 1){
                            double amount = scheme_cycle.getPlannedAmount().get(index);
                            Client clientTo = loop.get(0);
                            handleTransfer(paySim, currentStep, amount, clientTo);
                            launderedMoney += amount;
                            totalTransactions += 1;
                        }
                        if(index < loop.size() - 1){
                            double amount = scheme_cycle.getPlannedAmount().get(index);
                            Client clientTo = loop.get(index + 1);
                            handleTransfer(paySim, currentStep, amount, clientTo);
                            launderedMoney += amount;
                            totalTransactions += 1;
                            clientTo.reserved += scheme_cycle.getPlannedAmount().get(index + 1);
                            clientTo.setSuspicious(true);
                        }
                    }
                }
            }     
        }

        this.isLaunderingMoney = false;

        // Perform normal transactions
        if (stepTargetCount > 0) {
            MersenneTwisterFast random = paySim.random;
            int step = (int) state.schedule.getSteps();
            Map<String, Double> stepActionProfile = paySim.getStepProbabilities();

            int count = pickCount(random, stepTargetCount);

            for (int t = 0; t < count; t++) {
                String action = pickAction(random, stepActionProfile);
                StepActionProfile stepAmountProfile = paySim.getStepAction(action);
                double amount = pickAmount(random, action, stepAmountProfile);

                makeTransaction(random, paySim, step, action, amount);
                totalTransactions++;
            }
        }
    }

    protected int pickCount(MersenneTwisterFast random, int targetStepCount) {
        // B(n,p): n = targetStepCount & p = clientWeight
        Binomial transactionNb = new Binomial(targetStepCount, clientWeight, random);
        return transactionNb.nextInt();
    }

    protected String pickAction(MersenneTwisterFast random, Map<String, Double> stepActionProb) {
        Map<String, Double> clientProbabilities = clientProfile.getActionProbability();
        Map<String, Double> rawProbabilities = new HashMap<>();
        RandomCollection<String> actionPicker = new RandomCollection<>(random);

        // Pick the compromise between the Step distribution and the Client distribution
        for (Map.Entry<String, Double> clientEntry : clientProbabilities.entrySet()) {
            String action = clientEntry.getKey();
            double clientProbability = clientEntry.getValue();
            double rawProbability;

            if (stepActionProb.containsKey(action)) {
                double stepProbability = stepActionProb.get(action);

                rawProbability = (clientProbability + stepProbability) / 2;
            } else {
                rawProbability = clientProbability;
            }
            rawProbabilities.put(action, rawProbability);
        }

        // Correct the distribution so the balance of the account do not diverge too much
        double probInflow = 0;
        for (Map.Entry<String, Double> rawEntry : rawProbabilities.entrySet()) {
            String action = rawEntry.getKey();
            if (isInflow(action)) {
                probInflow += rawEntry.getValue();
            }
        }
        double probOutflow = 1 - probInflow;
        double newProbInflow = computeProbWithSpring(probInflow, probOutflow, balance);
        double newProbOutflow = 1 - newProbInflow;

        for (Map.Entry<String, Double> rawEntry : rawProbabilities.entrySet()) {
            String action = rawEntry.getKey();
            double rawProbability = rawEntry.getValue();
            double finalProbability;

            if (isInflow(action)) {
                finalProbability = rawProbability * newProbInflow / probInflow;
            } else {
                finalProbability = rawProbability * newProbOutflow / probOutflow;
            }
            actionPicker.add(finalProbability, action);
        }

        return actionPicker.next();
    }

    /**
     *  The Biased Bernoulli Walk we were doing can go far to the equilibrium of an account
     *  To avoid this we conceptually add a spring that would be attached to the equilibrium position of the account
     */
    private double computeProbWithSpring(double probUp, double probDown, double currentBalance){
        double equilibrium = 40 * expectedAvgTransaction; // Could also be the initial balance in other models
        double correctionStrength = 3 * Math.pow(10, -5); // In a physical model it would be 1 / 2 * kB * T
        double characteristicLengthSpring = equilibrium;
        double k = 1 / characteristicLengthSpring;
        double springForce = k * (equilibrium - currentBalance);
        double newProbUp = 0.5d * ( 1d + (expectedAvgTransaction * correctionStrength) * springForce + (probUp - probDown));

        if (newProbUp > 1){
           newProbUp = 1;
        } else if (newProbUp < 0){
            newProbUp = 0;
        }
        return newProbUp;

    }

    private boolean isInflow(String action){
        String[] inflowActions = {CASH_IN, DEPOSIT};
        return Arrays.stream(inflowActions)
                .anyMatch(action::equals);
    }

    protected double pickAmount(MersenneTwisterFast random, String action, StepActionProfile stepAmountProfile) {
        ClientActionProfile clientAmountProfile = clientProfile.getProfilePerAction(action);

        double average, std;
        if (stepAmountProfile != null) {
            // We take the mean between the two distributions
            average = (clientAmountProfile.getAvgAmount() + stepAmountProfile.getAvgAmount()) / 2;
            std = Math.sqrt((Math.pow(clientAmountProfile.getStdAmount(), 2) + Math.pow(stepAmountProfile.getStdAmount(), 2))) / 2;
        } else {
            average = clientAmountProfile.getAvgAmount();
            std = clientAmountProfile.getStdAmount();
        }

        double amount = -1;
        while (amount <= 0) {
            amount = random.nextGaussian() * std + average;
        }

        return amount;
    }

    protected void makeTransaction(MersenneTwisterFast random, PaySim state, int step, String action, double amount) {
        switch (action) {
            case CASH_IN:
                handleCashIn(state, step, amount);
                break;
            case CASH_OUT:
                handleCashOut(state, step, amount);
                break;
            case DEBIT:
                handleDebit(state, step, amount);
                break;
            case PAYMENT:
                handlePayment(state, step, amount);
                break;
            // For transfer transaction there is a limit so we have to split big transactions in smaller chunks
            case TRANSFER:
                //Paysim2 replace pickrandomclient with pick random connected client
                //Client clientTo = state.pickRandomClient(getName());

                double outsideNetworkProbability = random.nextDouble();
                Client clientTo;

                //Paysim2 has an 85% chance to Perform the transfer within the transaction network and a 15% to perform it to a random client 
                //TODO: Define the value of outsideNetworkProbability in PaySim.properties file 
                if(outsideNetworkProbability < 0.85)
                {
                    clientTo = state.pickConnectedClient(this);
                }
                else{
                    clientTo = state.pickRandomClient(getName());
                }
                
                if(this.getVertice() != null && clientTo.getVertice() != null)
                                {
                                    state.TG.addEdge(this.getVertice(), clientTo.getVertice());
                                }else
                                {
                                    System.out.println("One vertex was null" + this.getVertice() + " " + clientTo.getVertice());
                                }

                double reducedAmount = amount;
                boolean lastTransferFailed = false;
                while (reducedAmount > Parameters.transferLimit && !lastTransferFailed) {
                    lastTransferFailed = !handleTransfer(state, step, Parameters.transferLimit, clientTo);
                    reducedAmount -= Parameters.transferLimit;
                }
                if (reducedAmount > 0 && !lastTransferFailed) {
                    handleTransfer(state, step, reducedAmount, clientTo);
                }
                break;
            case DEPOSIT:
                handleDeposit(state, step, amount);
                break;
            default:
                throw new UnsupportedOperationException("Action not implemented in Client");
        }
    }

    protected void handleCashIn(PaySim paysim, int step, double amount) {
        Merchant merchantTo = paysim.pickRandomMerchant();
        String nameOrig = this.getName();
        String nameDest = merchantTo.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = merchantTo.getBalance();

        this.deposit(amount);

        double newBalanceOrig = this.getBalance();
        double newBalanceDest = merchantTo.getBalance();

        Transaction t = new Transaction(step, CASH_IN, amount, nameOrig, oldBalanceOrig,
                newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);
        paysim.getTransactions().add(t);
    }

    protected void handleCashOut(PaySim paysim, int step, double amount) {
        Merchant merchantTo = paysim.pickRandomMerchant();
        String nameOrig = this.getName();
        String nameDest = merchantTo.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = merchantTo.getBalance();

        boolean isUnauthorizedOverdraft = this.withdraw(amount);

        double newBalanceOrig = this.getBalance();
        double newBalanceDest = merchantTo.getBalance();

        Transaction t = new Transaction(step, CASH_OUT, amount, nameOrig, oldBalanceOrig,
                newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);

        t.setUnauthorizedOverdraft(isUnauthorizedOverdraft);
        t.setFraud(this.isFraud());
        paysim.getTransactions().add(t);
    }

    protected void handleDebit(PaySim paysim, int step, double amount) {
        String nameOrig = this.getName();
        String nameDest = this.bank.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = this.bank.getBalance();

        boolean isUnauthorizedOverdraft = this.withdraw(amount);

        double newBalanceOrig = this.getBalance();
        double newBalanceDest = this.bank.getBalance();

        Transaction t = new Transaction(step, DEBIT, amount, nameOrig, oldBalanceOrig,
                newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);

        t.setUnauthorizedOverdraft(isUnauthorizedOverdraft);
        paysim.getTransactions().add(t);
    }

    protected void handlePayment(PaySim paysim, int step, double amount) {
        Merchant merchantTo = paysim.pickRandomMerchant();

        String nameOrig = this.getName();
        String nameDest = merchantTo.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = merchantTo.getBalance();

        boolean isUnauthorizedOverdraft = this.withdraw(amount);
        if (!isUnauthorizedOverdraft) {
            merchantTo.deposit(amount);
        }

        double newBalanceOrig = this.getBalance();
        double newBalanceDest = merchantTo.getBalance();

        Transaction t = new Transaction(step, PAYMENT, amount, nameOrig, oldBalanceOrig,
                newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);

        t.setUnauthorizedOverdraft(isUnauthorizedOverdraft);
        paysim.getTransactions().add(t);
    }

    protected boolean handleTransfer(PaySim paysim, int step, double amount, Client clientTo) {
        String nameOrig = this.getName();
        String nameDest = clientTo.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = clientTo.getBalance();
        boolean transferSuccessful;

        if(this.isLaunderingMoney){
            this.release(amount);
            clientTo.deposit(amount);

            double newBalanceOrig = this.getBalance();
            double newBalanceDest = clientTo.getBalance();

            Transaction t = new Transaction(step, TRANSFER, amount, nameOrig, oldBalanceOrig,
                    newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);

            t.setUnauthorizedOverdraft(false);
            t.setFraud(this.isFraud());
            t.setSuspicious(this.isLaunderingMoney);
            paysim.getTransactions().add(t);

            //Paysim2 adds edge to transaction graph containing only moneylaundering transactions
            paysim.MLGraph.addVertice(this.getVertice());
            paysim.MLGraph.addVertice(clientTo.getVertice());
            paysim.MLGraph.addEdge(this.getVertice(), clientTo.getVertice());

            totalTransfers++;
            totalMLTransfers++;
            return true;
        }
        else{
            if (!isDetectedAsFraud(amount)) {
                boolean isUnauthorizedOverdraft = this.withdraw(amount);
                transferSuccessful = !isUnauthorizedOverdraft;
                if (transferSuccessful) {
                    clientTo.deposit(amount);
                }
    
                double newBalanceOrig = this.getBalance();
                double newBalanceDest = clientTo.getBalance();
    
                Transaction t = new Transaction(step, TRANSFER, amount, nameOrig, oldBalanceOrig,
                        newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);
                t.setUnauthorizedOverdraft(isUnauthorizedOverdraft);
                t.setFraud(this.isFraud());
                t.setSuspicious(this.isLaunderingMoney);
                paysim.getTransactions().add(t);
                totalTransfers++;
            } else { // create the transaction but don't move any money as the transaction was detected as fraudulent
                transferSuccessful = false;
                double newBalanceOrig = this.getBalance();
                double newBalanceDest = clientTo.getBalance();
    
                Transaction t = new Transaction(step, TRANSFER, amount, nameOrig, oldBalanceOrig,
                        newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);
    
                t.setFlaggedFraud(true);
                t.setFraud(this.isFraud());
                paysim.getTransactions().add(t);
                totalTransfers++;
            }
            return transferSuccessful;
        }
    }

    protected void handleDeposit(PaySim paysim, int step, double amount) {
        String nameOrig = this.getName();
        String nameDest = this.bank.getName();
        double oldBalanceOrig = this.getBalance();
        double oldBalanceDest = this.bank.getBalance();

        this.deposit(amount);

        double newBalanceOrig = this.getBalance();
        double newBalanceDest = this.bank.getBalance();

        Transaction t = new Transaction(step, DEPOSIT, amount, nameOrig, oldBalanceOrig,
                newBalanceOrig, nameDest, oldBalanceDest, newBalanceDest);

        paysim.getTransactions().add(t);
    }

    private boolean isDetectedAsFraud(double amount) {
        boolean isFraudulentAccount = false;//
        if (this.countTransferTransactions >= MIN_NB_TRANSFER_FOR_FRAUD) {
            if (this.balanceMax - this.balance - amount > Parameters.transferLimit * 2.5) {
                isFraudulentAccount = true;
            }
        } else {
            this.countTransferTransactions++;
            this.balanceMax = max(this.balanceMax, this.balance);
        }
        return isFraudulentAccount;
    }

    private double pickOverdraftLimit(MersenneTwisterFast random){
        double stdTransaction = 0;

        for (String action: ActionTypes.getActions()){
            double actionProbability = clientProfile.getActionProbability().get(action);
            ClientActionProfile actionProfile = clientProfile.getProfilePerAction(action);
            expectedAvgTransaction += actionProfile.getAvgAmount() * actionProbability;
            stdTransaction += Math.pow(actionProfile.getStdAmount() * actionProbability, 2);
        }
        stdTransaction = Math.sqrt(stdTransaction);

        double randomizedMeanTransaction = random.nextGaussian() * stdTransaction + expectedAvgTransaction;

        return BalancesClients.getOverdraftLimit(randomizedMeanTransaction);
    }

    public void SetConnectedClients(PaySim paySim, String vertice){
        ArrayList<Integer> connectedVertices = paySim.PTG.getDestinations(vertice);
        for(Integer c : connectedVertices){
            connectedClients.add(paySim.getClients().get(c));
        }
    }


    public ArrayList<Client> getConnectedClients(){
        return this.connectedClients;
    }

    public void setSuspicious(boolean isSuspicious) {
        this.isSuspicious = isSuspicious;
    }
    public Bank getBank(){
        return this.bank;
    }
    public void setBank(Bank bank){
        this.bank = bank;
    }

    public boolean isSuspicious(){
        return this.isSuspicious;
    }

    @Override
    public String toString() {
        ArrayList<String> properties = new ArrayList<>();

        properties.add(getName());
        properties.add(bank.getName());
        properties.add(Output.fastFormatDouble(Output.PRECISION_OUTPUT, initialBalance));
        properties.add(Output.fastFormatDouble(Output.PRECISION_OUTPUT, clientWeight));
        properties.add(Integer.toString(totalTransactions));
        properties.add(Integer.toString(totalTransfers));
        properties.add(Integer.toString(totalMLTransfers));
        properties.add(Integer.toString(nbCycle));
        properties.add(Integer.toString(nbFanOutFanIn));
        properties.add(Output.fastFormatDouble(Output.PRECISION_OUTPUT, launderedMoney));
        properties.add(this.getVertice());
        properties.add(Output.formatBoolean(this.isSuspicious));
        properties.add(Output.formatBoolean(this.isMoneyLaunderer));
        return String.join(Output.OUTPUT_SEPARATOR, properties);
    }
}
