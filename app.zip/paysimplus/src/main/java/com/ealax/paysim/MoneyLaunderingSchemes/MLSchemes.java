package com.ealax.paysim.MoneyLaunderingSchemes;

import java.util.ArrayList;

import com.ealax.paysim.actors.Client;
import com.ealax.paysim.actors.MoneyLaunderer;
import com.ealax.paysim.utils.*;

import ec.util.MersenneTwisterFast;
import sim.engine.SimState;
import com.ealax.paysim.PaySim;
import com.ealax.paysim.parameters.Parameters;

public class MLSchemes {
    protected double proportion = 0.9;//proportion of available money that would be laundered
    protected MoneyLaunderer Orig;
    protected SimState state;
    protected double ratio = 0.95;//amount of money that will be sent out compared to the received 

    public MLSchemes(MoneyLaunderer Orig, SimState state){
        this.Orig = Orig;
        this.state = state;
    }

    public MoneyLaunderer getOrig(){
        return Orig;
    }

    public double getRatio(){
        return ratio;
    }

    public double getProportion(){
        return proportion;
    }



}
