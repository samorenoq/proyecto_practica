package com.ealax.paysim.actors;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static java.lang.Math.max;

import java.util.ArrayList;

import com.ealax.paysim.output.Output;
import com.ealax.paysim.parameters.ActionTypes;
import com.ealax.paysim.parameters.BalancesClients;
import com.ealax.paysim.parameters.Parameters;
import ec.util.MersenneTwisterFast;
import sim.engine.SimState;
import sim.engine.Steppable;
import sim.util.distribution.Binomial;

import com.ealax.paysim.PaySim;
import com.ealax.paysim.MoneyLaunderingSchemes.*;
import com.ealax.paysim.base.ClientActionProfile;
import com.ealax.paysim.base.ClientProfile;
import com.ealax.paysim.base.StepActionProfile;
import com.ealax.paysim.base.Transaction;
import com.ealax.paysim.utils.ListUtils;
import com.ealax.paysim.utils.RandomCollection;
import com.ealax.paysim.utils.calendarUtils;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.*;
import java.util.HashMap; 

//The agent MoneyLaunderer will enter to simulation to try to launder money by performing one of a number of money laundering actions
//for example initiate a fan out fan in or a cycle transaction scheme. These actions will transfer some money to clients together with instructions on
//what to do with the money and how much to keep
public class MoneyLaunderer extends Client {

    private static final String MONEYLAUNDERER_IDENTIFIER = "C";
    private ArrayList<Client> moneyMules = new ArrayList<>();

    public MoneyLaunderer(PaySim paySim){
        super(paySim);
    }

    
    @Override
    public void step(SimState state) {
        PaySim paySim = (PaySim) state;
        int stepTargetCount = paySim.getStepTargetCount();
        int currentStep = (int) state.schedule.getSteps();
        
        //The value that checks if money laundering should take place
        double CycleP = Parameters.CycleProbability;
        double FanOutFanInP = Parameters.FanOutFanInProbability;
        double CycleThreshold = Parameters.CycleThreshold;
        double FanOutFanInThreshold = Parameters.FanOutFanInThreshold;

        double value = paySim.random.nextDouble();
        if(value < CycleP && (this.balance - this.reserved) > CycleThreshold){
            // System.out.println(this.balance + " - " + this.reserved);
            Cycle newScheme = new Cycle(this, paySim);
            newScheme.initiate();
            nbCycle += 1;
            // System.out.println("balance" + this.balance);
            // System.out.println("reserved" + this.reserved);

            System.out.println("amounts" + newScheme.getPlannedAmount());
            // System.out.println("steps" + newScheme.getPlannedSteps());
            // System.out.println(newScheme.getLoop());
        }
        

        value = paySim.random.nextDouble();
        if(value < FanOutFanInP && (this.balance - this.reserved) > FanOutFanInThreshold){
            // System.out.println(this.balance + " - " + this.reserved);
            FanOutFanIn newScheme = new FanOutFanIn(this, paySim);
            newScheme.initiate();
            nbFanOutFanIn += 1;
            // System.out.println("MONEYLAUNDERER initiated fanout fanin on step " + currentStep);
            // System.out.println("balance" + this.balance);
            // System.out.println("reserved" + this.reserved);
            System.out.println("amounts" + newScheme.getPlannedAmount());
            // System.out.println("steps" + newScheme.getPlannedSteps());
            // System.out.println("steps" + newScheme.getPlannedStepsFanIn());
        }
        
        

        this.isLaunderingMoney = true;

        for(MLSchemes scheme: this.MLPlan){
            if(scheme instanceof FanOutFanIn){
                FanOutFanIn scheme_fan = (FanOutFanIn) scheme;
                if(scheme_fan.getPlannedSteps().contains(currentStep)){
                    int index = scheme_fan.getPlannedSteps().indexOf(currentStep);
                    double amount = scheme_fan.getPlannedAmount().get(index);
                    Client clientTo = scheme_fan.getTargeClients().get(index);
                    handleTransfer(paySim, currentStep, amount, clientTo);
                    launderedMoney += amount;
                    totalTransactions += 1;
                    // System.out.println("clientTo" + clientTo);
                    // System.out.println("amount" + amount);
                    clientTo.reserved += amount * scheme_fan.getRatio();
                    clientTo.setSuspicious(true);
                    // System.out.println("MONEYLAUNDERER performed fan out with:" + amount + "from" + this.getName() + "to" + clientTo.getName());
                }
            }
            if(scheme instanceof Cycle){
                Cycle scheme_cycle = (Cycle) scheme;
                if(scheme_cycle.getPlannedSteps().get(0) == currentStep){
                    double amount = scheme_cycle.getPlannedAmount().get(0);
                    Client clientTo = scheme_cycle.getLoop().get(1);
                    handleTransfer(paySim, currentStep, amount, clientTo);
                    launderedMoney += amount;
                    totalTransactions += 1;
                    clientTo.reserved += scheme_cycle.getPlannedAmount().get(1);
                    clientTo.setSuspicious(true);
                }
            }
        }

        this.isLaunderingMoney = false;

        //Perform the normal transactions
        if (stepTargetCount > 0) {
            MersenneTwisterFast random = paySim.random;
            int step = (int) state.schedule.getSteps();
            Map<String, Double> stepActionProfile = paySim.getStepProbabilities();

            int count = pickCount(random, stepTargetCount);

            for (int t = 0; t < count; t++) {
                String action = pickAction(random, stepActionProfile);
                StepActionProfile stepAmountProfile = paySim.getStepAction(action);
                double amount = pickAmount(random, action, stepAmountProfile);
                makeTransaction(random, paySim, step, action, amount);
                totalTransactions += 1;
            }
        }
    }

    public void setMoneyMules(ArrayList<Client> moneyMules){
        this.moneyMules = moneyMules;
    }

    public ArrayList<Client> getMoneyMules(){
        return this.moneyMules;
    }
    
}