package com.ealax.paysim.parameters;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import com.ealax.paysim.parameters.Parameters;

import com.ealax.paysim.utils.CSVReader;

import org.apache.commons.exec.ExecuteException;


//Paysim2
//Read degree distribution files to generate a in_degree sequence and a out_degree sequence 
//Example: If in_degree = [1,0,2,3,..] out_degree = [2,3,4,0,...], it means that vertex v_0 is of indegree 1 and outdegree 2, v_1 is of indegree 0 and outdegree 3, and so on.
public class DegreeFile {
    private static final int COLUMN_COUNT = 0, COLUMN_IN = 1, COLUMN_OUT = 2;
    private ArrayList<Integer> in_degree = new ArrayList<Integer>(); 
    private ArrayList<Integer> out_degree = new ArrayList<Integer>();

    //Paysim2
    
    public DegreeFile(String filename) {
        ArrayList<String[]> parameters = CSVReader.read(filename);

        for (String[] paramLine : parameters) {
            int count = Integer.parseInt(paramLine[COLUMN_COUNT]);
            int in_degree_num = Integer.parseInt(paramLine[COLUMN_IN]);
            int out_degree_num = Integer.parseInt(paramLine[COLUMN_OUT]);

            for(int i=0; i<in_degree_num; i++){
                in_degree.add(count);
            }
            
            for(int i=0; i<out_degree_num; i++){
                out_degree.add(count);
            }
        }

        if(in_degree.size() != out_degree.size()){
            throw new Error("Check the transactionDegree.csv file. The length of In-degree and Out-degree sequences should be same.");
        }


        int total_in_degree = 0;
        for(int degree: in_degree){
            total_in_degree += degree;
        }

        int total_out_degree = 0;
        for(int degree: out_degree){
            total_out_degree += degree;
        }

        if(total_in_degree != total_out_degree){
            throw new Error("Check the transactionDegree.csv file. The sum of In-degree and Out-degree should be same.");
        }

        int numberClients = Parameters.nbClients;

        if(numberClients % in_degree.size() != 0){
            throw new Error("The number of total accounts must be a multiple of the degree sequence length.");
        }
    }

    public ArrayList<Integer> getInDegreeList(){
        return this.in_degree;
    }

    public ArrayList<Integer> getOutDegreeList(){
        return this.out_degree;
    }
     
    

}
