#!/usr/bin/env bash

cd paysimplus/outputs/
folder=$(awk -F',' 'END { print $1 }' summary.csv)
echo "$folder"
cd ../../
