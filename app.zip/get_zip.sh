#!/usr/bin/env bash

find ./*.zip && rm ./*.zip
folder=$(./get_fold.sh)
cd paysimplus/outputs/
name="result_$folder.zip"

# Zip
zip -r "$name" "$folder"
mv "$name" ../../
cd ../../
